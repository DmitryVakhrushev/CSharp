﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FishAndBears
{
    /// <summary>
    /// An enumeration for the sides of a game object
    /// </summary>
    enum Side
    {
        Left,
        Right
    }
}
